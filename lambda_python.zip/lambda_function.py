import json

def lambda_handler(event, context):
    # SQS events always deliver records in a list
    if 'Records' in event:
        for record in event['Records']:
            # Extract the raw message string
            message_body = record['body']
            print(f"Processing message: {message_body}")
            
            # If your message body is JSON, parse it:
            try:
                data = json.loads(message_body)
                print(f"Parsed JSON data: {data}")
            except json.JSONDecodeError:
                print("Message body is not valid JSON string.")
                
    return {
        'statusCode': 200,
        'body': json.dumps('SQS batch processed successfully')
    }
